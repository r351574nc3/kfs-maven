var g_ContentsURL = "KFS%204_x%20help-toc.htm";
var g_IndexURL = "KFS%204_x%20help-index.htm";
var g_SearchURL = "KFS%204_x%20help-search.htm";
var g_FavoritesURL = "KFS%204_x%20help-favorites.htm";
